<?php
    $db = ['servidor' => 'localhost','usuario' => 'root', 'password' => '','db' => 'articulos_db'];
