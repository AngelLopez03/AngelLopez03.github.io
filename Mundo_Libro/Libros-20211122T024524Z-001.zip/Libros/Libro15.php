<?php
    include '../funciones.php';
    include 'conex.php';
    $link=mysqli_connect("localhost","root","","proyecto");
    //$con=mysqli_query($link,$query);
    //$link=traerPorID($tabla,$id)
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Mundo Libro</title>
        <link rel="icon" href="../img/LIBRO.jfif">
        <link rel="stylesheet" href="../Css/style.css"/>
        <script src="https://kit.fontawesome.com/86dc997a7b.js" ></script>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="../js/script_blog.js"></script>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Kaushan+Script">
    </head>
    <body>
        <div class="contenedor">
            <header class="fila">
                <div id="logo" class="col-lg-3 col-md-4 col-sm-4 col-xs-12"><a href="index.php"><center>Mundo Libro</center></a></div>
                <div class="position col-lg-7 col-md-6 col-sm-6 col-xs-0">
                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-0"><a href="../index.php">INICIO</a></div>
                    <div class="col-lg-3 col-md-0 col-sm-0 col-xs-0"><a href="../nosotros.php">ACERCA DE</a></div>
                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-0"><a href="../libros.php">LIBROS</a></div>
                    <div class="col-lg-2 col-md-3 col-sm-3 col-xs-0"><a href="../Graficos.php">GRÁFICOS</a></div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-0"><a href="#">CONTACTANOS</a></div>
                </div>
        		<div class="position1 col-lg-2 col-md-2 col-sm-2 col-xs-12">
        			<div id="icono1" class="col-lg-6 col-md-6 col-sm-6 col-xs-6"><center><i class="fas fa-user"></i></center></div>
        			<div id="icono2" class="col-lg-6 col-md-6 col-sm-6 col-xs-6"><center><i class="fas fa-search"></i></center></div>
        			<!--div id="icono3" class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><center><i class="fas fa-cart-arrow-down"></i></center></div-->
        		</div>
                        
        	</header>
            <section class="fila" id="seccion2_book">
                <div class="cabecera col-lg-10 col-md-10 col-sm-10 col-xs-10">
                    <div class="container_img_book col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <img src="../bdImg/anaS.jpg" width="200" height="280" alt="Anas">
                    </div>

                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                            <p><b>Sinopsis:</b></p>
                        </div>
                        <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10"></div>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <p>
                                Ana y Mario tienen 14 años, no se soportan y se encuentran en Roma en viaje de estudios. Mientras contempla el techo de la Capilla Sixtina, Ana recibe una llamada de socorro de la Sibila de Cumas, una misteriosa adivina de los tiempos antiguos condenada a envejecer durante mil años. Esa misma noche, la joven escapa del hotel y se interna entre las calles de la ciudad para emprende un rescate a través del tiempo, nada menos que hasta la Roma imperial. Pero Mario sospecha algo y, en el último momento, decide no abandonarla en su peligrosa aventura. Ana y la Sibila es una historia trepidante y sensible a la vez, donde la auténtica amistad se une a la curiosidad por los misterios del pasado.
                            </p>
                        </div>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            
                            <!--PARTE DE ARRIBA-->
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><b><p>AUTOR:</p></b></div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><b><p>AÑO DE PUBLICACIÓN</p></b></div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><b><p>RANKING</p></b></div>

                            <!--RELLENO O PARTE DE ABAJO-->
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">Antonio Sánchez-Escalonilla</div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">2013</div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">,...........</div>
                        </div>
                    </div>
                </div>
            </section>
        	<section class="fila" id="seccion3_book">
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                    <div class="articulo col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <h1><b>Ana y la sibila</b></h1>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <h1><b></b></h1>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <h2><b>Resumen</b></h2>
                        </div>
                        
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <p>
                                Ana es una chica que se va de viaje de fin de curso a Roma. Allí visita la Capilla Sixtina, donde ve una obra de Miguel Ángel, en que sale la Sibila de Cumas, llamada Amaltes. Allí conoce a un guía llamado Virgilio Marone. Él le explica la curiosa historia de la Sibila y Ana se queda traspuesta y pensativa. De repente un fuerte vendaval remueve el lugar. Ana ve un papel en el suelo... ¡Era un oráculo en latín de la Sibila! Lo coge sin pensárselo y se va corriendo con sus compañeros.

                                Cuando están en el hotel, recibe la llamada del Virgilio que le dice que vaya al arco de Jano a medianoche.

                                Ella coge su mochila y se va. Allí se encuentra a Virgilio, pero al llegar al arco, una fuerza misteriosa intenta detenerla. Pero ella corre hacia al arco para atravesarlo, mientras Virgilio le dice que debe seguir las indicaciones de la Sibila.
<br>
<br>
                                Al traspasar el arco se encuentra en Sagunto en plena guerra. Allí be que su compañero Mario le ha seguido y que han viajado los dos en el tiempo.

                                Allí salvan a una chica llamada Lida, y se hacen amigos. Gracias a ella y a su amigo guerrero, Dibus, que se ocupaba de ella, pudieron escapar de los ejércitos de Cartago y huir de la ciudad.

                                Van buscando un refugio lejos de allí, cuando se encuentran con otra guerra y Dibus y Mario deben luchar en ella. Pero Dibus muere en ella salvando a Mario. Al terminar, los demás siguen la aventura sin Dibus. Se van por mar con un barco, pero se vuelca, y viajan en el tiempo. Pero un animal que parece ser una ballena o un delfín les salva y les lleva al río Tíber. Allí conocen el hijo de un general y almirante de Roma que les ayuda en la aventura del oráculo.
<br>
<br>
                                Bajan a las cloacas de la ciudad, siguiendo el oráculo.

                                En la cena en que, Marco les invita a cenar, descubre que Publio Virgilio Marone es el autor de la Envidia e intenta hablar con él, pero no lo consigue y se va a dormir.

                                Al día siguiente asisten al desfile o ceremonia que hay en la ciudad, allí consigue hablar con Virgilio que le dice que debe cruzar a puerta, pero sus amigos están atrapados. Y como no tiene otra alternativa cruza el umbral para resolver todo este misterio.
<br>
<br>
                                La chica va a parar a la cueva de la Sibila de Cumas, donde se encuentra con el dios Saturno, que le dice que si se queda en la cueva, él salvaría a sus amigos.

                                Mientras Ana está en el lugar, de repente empieza a caerse al vacío. Al momento aparece en la Capilla Sixtina. Se encuentra con Miguel Ángel pintando el cuadro. Él ve a Ana muy parecida a la Sibila y le pregunta si lo es. Ella lo niega.

                                Mario estaba de ser lanzado por un acantilado, pero Ana llegó a tiempo y lo salvó y volvieron los dos a su siglo, el XXI, pero sin su amiga, Lida.
<br>
<br>
                                Por mucho que habían viajado en el tiempo, el tiempo no había transcurrido en su siglo. El último día del viaje volvieron a la Capilla Sixtina y vieron en el fresco de Miguel Ángel, en la cara de la Sibila, la imagen de ana reflejada. Ana entonces pensó que todo lo que había vivido en los siglos pasados, viajando en el tiempo, no había sido ningún sueño ni ninguna imaginación.

                                Regresaron a Cartagena todos, y les llegó de forma increíble una carta de Lida, en la que decía que acudieran al puerto. Al llegar vieron a Ana y a Virgilio, que llegaban en un ferry. Ella les dijo que aun no estaba acostumbrada a esas épocas y que solo les visitaría en verano, y los dos se dieron la vuelta y subieron la pasarela del ferry.
                            </p>
                        </div>
                        
                        
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <h1><b>Capítulo II: El tamaño de la tierra</b></h1>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <p>

                            </p>
                        </div>
                    </div>
                </div>


                    <div class="container-aside col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <aside>
                            <h1>Recomendados</h1>
                        </aside>

                            
                        <?php                            
                        $query = "SELECT * FROM libros limit 7,2 ";
                        $result = mysqli_query($link, $query);

                         
                        if (mysqli_num_rows($result)  >0 ) {
                         
                            while($fila = mysqli_fetch_assoc($result) ){
                                $titulo= $fila["title"];
                                $img= $fila["foto"];
                                $link = $fila["link"];
                                $post=postaside("../$link", "$titulo","../$img"," ", " ");                            } 
                        } else {
                            die("Error: No hay datos en la tabla seleccionada");
                        }                            
                    ?>
                    </div>
                </div>
            </section>
        <footer class="fila col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="col-lg-10 col-md-12 col-sm-12 col-xs-12">
            <div class="content_nosotros col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="col-lg-2 col-md-2 col-sm-1 col-xs-12">
                            <a href="index.php" class="txt">INCIO</a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-2 col-xs-12">
                            <a href="#" class="txt">ACERCA DE</a>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <a href="libros.php" class="txt">LIBROS</a>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <a href="Graficos.php" class="txt">GRÁFICOS</a>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <a href="#" class="txt">CONTACTANOS</a>
                        </div>
                        <div class="col-lg-0 col-md-0 col-sm-2 col-xs-12">
                            <a href="#" class="txt">LOGIN</a>
                        </div>
                    </div>
                </div>
                <div class="nosotros col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="titulo space col-lg-12 col-md-12 col-sm-12 col-xs-12"><p>NOSOTROS</p></div>
                    <div id="title" class="titulo col-lg-12 col-md-12 col-sm-12 col-xs-12">MUNDO LIBRO</div>
                    <div class="txt space col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus ex dolor eos quos suscipit. Quis a dolorem repudiandae, reprehenderit commodi esse voluptatibus exercitationem distinctio ipsum. Facilis aliquid optio consequuntur eum!
                        </p>
                    </div>
                    <div class="titulo space col-lg-12 col-md-12 col-sm-12 col-xs-12">MANTENTE CONECTADO</div>
                    <div class="titulo col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">f</div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">t</div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">G</div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">G+</div>
                    </div>
                </div>
                <div class="destacado col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="titulo col-lg-12 col-md-12 col-sm-12 col-xs-12">CONTENIDO DESTACADO</div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="txt">asistencia a la investigación</a>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="txt">Pago del libro</a>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="txt">Libros electrónicos</a>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="txt">Archivo</a>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="txt">Referencia electrónica</a>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="txt">Revistas</a>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="txt">Comunicados de prensa</a>
                    </div>
                </div>
            </div>

            <div class="contenedor_otros col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-0">
                    <div class="col-lg-10 col-md-10 col-sm-0 col-xs-0"></div>
                    <div class="col-lg-2 col-md-2 col-sm-0 col-xs-0">
                        <a href="#" class="txt col-xs-0">LOGIN</a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">


                    <div class="titulo col-lg-12 col-md-12 col-sm-12 col-xs-12">ÚLTIMOS LANZAMIENTOS</div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="comm">
                            Lorem ipsum dolor, sit, amet consectetur adipisicing elit. Eius fuga porro, blanditiis inventore est sit eligendi corrupti delectus dicta vitae aut unde nostrum sint quas molestiae nulla in quidem cupiditate!
                        </a>
                    </div>

                    <div class="txt col-lg-12 col-md-12 col-sm-12 col-xs-12">Febrero 15, 2018</div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="comm">
                            Lorem ipsum dolor, sit, amet consectetur adipisicing elit. Eius fuga porro, blanditiis inventore est sit eligendi corrupti delectus dicta vitae aut unde nostrum sint quas molestiae nulla in quidem cupiditate!
                        </a>
                    </div>

                    <div class="txt col-lg-12 col-md-12 col-sm-12 col-xs-12">Febrero 15, 2018</div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="#" class="comm">
                            Lorem ipsum dolor, sit, amet consectetur adipisicing elit. Eius fuga porro, blanditiis inventore est sit eligendi corrupti delectus dicta vitae aut unde nostrum sint quas molestiae nulla in quidem cupiditate!
                        </a>
                    </div>

                    <div class="txt col-lg-12 col-md-12 col-sm-12 col-xs-12">Febrero 15, 2018</div>

                    
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="titulo col-lg-12 col-md-12 col-sm-12 col-xs-12">CONTACTANOS</div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <input type="text" placeholder="Nombre" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <input type="text" placeholder="Correo" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <input type="text" placeholder="Mensaje" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    </div>

                    <div class="col-lg-4 col-md-5 col-sm-5 col-xs-5">
                        <button class="col-lg-12 col-md-12 col-sm-12 col-xs-12" type="submit">ENVIAR</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="contenedor_derechos col-lg-12 col-md-12 col-sm-12 col-xs-12">
            © 2021 Mundo Libro. Todos los derechos reservados | Diseñado por 3ero <b>INFOR.</b>
        </div>
 	</footer>
    </body>
</html>
